import json
import os
import platform

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SYSTEM_JSON_PATH = os.path.join(BASE_DIR, "..", "..", "imp", "system.json")

with open(SYSTEM_JSON_PATH, "r+") as SYSTEM_INFO:
    SYSTEM_INFO_JSON = json.loads(SYSTEM_INFO.read())

HOSTNAME = SYSTEM_INFO_JSON['HOSTNAME']
BASE_IMAGE = SYSTEM_INFO_JSON['BASE']

PYBOX_ASCII_ART_WORDART = f'''
██████╗ ██╗   ██╗██████╗  ██████╗ ██╗  ██╗  HOSTNAME: {HOSTNAME}
██╔══██╗╚██╗ ██╔╝██╔══██╗██╔═══██╗╚██╗██╔╝  BASE IMAGE: {BASE_IMAGE}
██████╔╝ ╚████╔╝ ██████╔╝██║   ██║ ╚███╔╝   HOST PLATFORM: {platform.platform()}
██╔═══╝   ╚██╔╝  ██╔══██╗██║   ██║ ██╔██╗
██║        ██║   ██████╔╝╚██████╔╝██╔╝ ██╗
╚═╝        ╚═╝   ╚═════╝  ╚═════╝ ╚═╝  ╚═╝
(Power . Your . BOX)
'''

print(PYBOX_ASCII_ART_WORDART)